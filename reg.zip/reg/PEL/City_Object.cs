﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace reg.App
{
    public class City_Object
    {
        private int _cityID;

        public int CityID
        {
            get { return _cityID; }
            set { _cityID = value; }
        }
        private string _cityname;

        public string Cityname
        {
            get { return _cityname; }
            set { _cityname = value; }
        }

    }
}