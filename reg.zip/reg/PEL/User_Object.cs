﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace reg.App
{
    public class User_Object
    {
        private int _userID;

        public int UserID
        {
            get { return _userID; }
            set { _userID = value; }
        }

        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        private long _phonenumber;

        public long Phonenumber
        {
            get { return _phonenumber; }
            set { _phonenumber = value; }
        }
        private string _email;

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        private string _password;

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }
        private string _address;

        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }
        private string _country;

        public string Country
        {
            get { return _country; }
            set { _country = value; }
        }
        private string _city;

        public string City
        {
            get { return _city; }
            set { _city = value; }
        }
        private long _pincode;


        public long Pincode
        {
            get { return _pincode; }
            set { _pincode = value; }
        }
        private string securityquestion;

        public string Securityquestion
        {
            get { return securityquestion; }
            set { securityquestion = value; }
        }
        private string securityanswer;

        public string Securityanswer
        {
            get { return securityanswer; }
            set { securityanswer = value; }
        }

    }
}