﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace reg.App
{
    public class Offer_Object
    {
        private int _offerID;

        public int OfferID
        {
            get { return _offerID; }
            set { _offerID = value; }
        }
        private string _offername;

        public string Offername
        {
            get { return _offername; }
            set { _offername = value; }
        }
        private string _offerdescription;

        public string Offerdescription
        {
            get { return _offerdescription; }
            set { _offerdescription = value; }
        }
        private int _percentoff;

        public int Percentoff
        {
            get { return _percentoff; }
            set { _percentoff = value; }
        }
    }
}