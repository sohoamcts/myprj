﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace reg.App
{
    public class Room_Object
    {
        private int _roomID;

        public int RoomID
        {
            get { return _roomID; }
            set { _roomID = value; }
        }
        private string _hotelname;

        public string Hotelname
        {
            get { return _hotelname; }
            set { _hotelname = value; }
        }
        private int _cityID;

        public int CityID
        {
            get { return _cityID; }
            set { _cityID = value; }
        }
        private string _description;

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        private int _noofACs;

        public int NoofACs
        {
            get { return _noofACs; }
            set { _noofACs = value; }
        }
        private double _rentofACroom;

        public double RentofACroom
        {
            get { return _rentofACroom; }
            set { _rentofACroom = value; }
        }
        private double _rentofnonACroom;

        public double RentofnonACroom
        {
            get { return _rentofnonACroom; }
            set { _rentofnonACroom = value; }
        }
        private int _offerID;

        public int OfferID
        {
            get { return _offerID; }
            set { _offerID = value; }
        }
        private int _noofrooms;

        public int Noofrooms
        {
            get { return _noofrooms; }
            set { _noofrooms = value; }
        }
        private int _bookedfrom;

        public int Bookedfrom
        {
            get { return _bookedfrom; }
            set { _bookedfrom = value; }
        }
        private int _bookedto;

        public int Bookedto
        {
            get { return _bookedto; }
            set { _bookedto = value; }
        }

        private int _capacityadult;

        public int Capacityadult
        {
            get { return _capacityadult; }
            set { _capacityadult = value; }
        }
        private int _capacitychildren;

        public int Capacitychildren
        {
            get { return _capacitychildren; }
            set { _capacitychildren = value; }
        }

    }
}