﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace reg
{
    public partial class registration : System.Web.UI.Page
    {
        //Business_Layer BL = new Business_Layer();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            //User_Object UO = new User_Object();
            //UO.Name = TextBox1.Text;
            //UO.Phonenumber = Convert.ToInt64(TextBox2.Text);
            //UO.Email = TextBox3.Text;
            //UO.Password = TextBox4.Text;
            //UO.Address = TextBox6.Text;
            //UO.Country = TextBox7.Text;
            //UO.City = TextBox8.Text;
            //UO.Pincode = Convert.ToInt64(TextBox9.Text);
            //UO.Securityquestion = DropDownList1.SelectedValue;
            //UO.Securityanswer =
            //UO.UserID = Convert.ToInt32(BL.get_user_id());
            //string message = BL.user_registration_process(UO);
            
            
            //    Label1.Text = "Login is Successful";
            //    Button1.Visibility = false;
            
            
           
            
                //Label1.Text = "Login is UnSuccessful... Please try again !!";
            
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
           
        }
}
}