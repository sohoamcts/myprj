﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SaveUserDetails
{
    public class SaveUser
    {
        public string _cityID { get; set; }
        public string _cityname { get; set; }
       
    }
}
