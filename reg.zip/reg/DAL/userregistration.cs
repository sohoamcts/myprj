﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

//namespace DAL
//{
//    public class userregistration
//    {
//        //public string User_Registration(User_Object user_details)
        //{
        //    con.Open();
        //    SqlCommand cmd = new SqlCommand("User_SignUp", con);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    try
        //    {
        //        cmd.Parameters.AddWithValue("@log_id", Convert.ToInt64(user_details.UserID));
        //        cmd.Parameters.AddWithValue("@name", user_details.Name);
        //        cmd.Parameters.AddWithValue("@phone", Convert.ToInt64(user_details.Phonenumber));
        //        cmd.Parameters.AddWithValue("@email", user_details.Email);
        //        cmd.Parameters.AddWithValue("@password", user_details.Password);
        //        cmd.Parameters.AddWithValue("@address", user_details.Address);
        //        cmd.Parameters.AddWithValue("@country", user_details.Country);
        //        cmd.Parameters.AddWithValue("@city", user_details.City);
        //        cmd.Parameters.AddWithValue("@pin", Convert.ToInt64(user_details.Pincode));
        //        cmd.Parameters.AddWithValue("@securityqstn", user_details.Securityquestion);
        //        cmd.Parameters.AddWithValue("@securityans", user_details.Securityanswer);

        //        return cmd.ExecuteNonQuery().ToString();
        //    }
//            catch (Exception show_error)
//            {
//                throw show_error;
//            }
//            finally
//            {
//                cmd.Dispose();
//                con.Close();
//                con.Dispose();
//            }

//        }
//    }
//}
